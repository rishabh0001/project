package com.cg.bank.ui;

import java.util.Scanner;

import com.cg.bank.dto.Customer;
import com.cg.bank.exception.BankAccountException;
import com.cg.bank.service.BankAccountServiceImpl;
//Main Method
public class Main {
	public static void main(String args[]) throws BankAccountException{
		//Service Object
		BankAccountServiceImpl service = new BankAccountServiceImpl();
		
		Scanner sc = new Scanner(System.in);
		@SuppressWarnings("resource")
		Scanner sc1 = new Scanner(System.in);
		
		
		String name,mobileNo;
		float age;
		double amount;
		int ch = 0;
		do{
			System.out.println("\n----------------Menu----------------");
			System.out.println("1) Add Customer Account");
			System.out.println("2) Deposit");
			System.out.println("3) Withdraw");
			System.out.println("4) Fund Transfer");
			System.out.println("5) Check Balance");
			System.out.println("6) Exit\n");
			ch = sc.nextInt();
			Customer customer;
			switch(ch){
				case 1 ://Add Customer
					
						do{//getting user details
							do{
							System.out.println("Enter your first & last name");
							name = sc1.nextLine();
							if(service.validateName(name))
								break;
							
							}while(true);
							do{System.out.println("Enter 10 digits valid mobile no");
							mobileNo = sc.next();
							if(service.validateMobileNo(mobileNo))
								break;
							}while(true);
							do{
							System.out.println("Enter your age");
							age = sc.nextFloat();
							if(service.validateAge(age))
								break;
							}while(true);
							do{
							System.out.println("Enter initial amount");
							amount = sc.nextDouble();

							if(service.validateAmount(amount))
								break;
							}while(true);
							if(service.validateAccount(mobileNo)){
									System.out.println("----WARNING----\nAccount Already Exists");
								}else{
								break;
							}
							
						}while(true);
						
						customer = new Customer();
						
						customer.setName(name);
						customer.setMobileNo(mobileNo);
						customer.setAge(age);
						customer.setInitialBalance(amount);
						
						service.createAccount(customer);						
						System.out.println("\n----------New Customer Added---------");
											break;
						
				case 2 ://Deposit
						do{
							System.out.println("Enter beneficiary mobile number");
							mobileNo = sc.next();
							
							System.out.println("Enter the amount you want to deposit--Amount must be greater than 0 and less than 10000000");
							amount = sc.nextDouble();
							if(service.validateMobileNo(mobileNo)&& service.validateAmount(amount)){
								if(service.validateAccount(mobileNo))
									break;
							}
						}while(true);
						
						service.deposit(mobileNo, amount);						
					
					break;
					
				case 3 ://Withdraw
						do{
							System.out.println("Enter withdrawer's mobile number");
							mobileNo = sc.next();
							
							System.out.println("Enter the amount you want to withdraw----Amount must be greater than 0 and less than 10000000");
							amount = sc.nextDouble();
							if(service.validateMobileNo(mobileNo) && service.validateAmount(amount)){
								if(service.validateAccount(mobileNo))
									break;
							}
						}while(true);
						
						service.withdraw(mobileNo, amount);
						
					break;
				
				case 4 ://Fund Transfer
						String mobileNoReciever;
						do{
							System.out.println("Enter your mobile number");
							mobileNo = sc.next();
							
							System.out.println("Enter the amount you want to transfer---Amount must be greater than 0 and less than 10000000");
							amount = sc.nextDouble();
							
							System.out.println("Enter beneficiary mobile number");
							mobileNoReciever = sc.next();
							if(service.validateMobileNo(mobileNo) && service.validateMobileNo(mobileNoReciever) && service.validateAmount(amount) && service.validateAccount(mobileNoReciever)){
								if(service.validateAccount(mobileNoReciever) && service.validateAccount(mobileNo))
									if(!mobileNo.equals(mobileNoReciever))
										
										break;
									else{
										System.out.println("----WARNING----\nMobile Numbers cannot be the same!");
									}
							}
							else
							{
								System.out.println("----WARNING----Insert the mobile no. which is already registered");
							}
						}while(true);
					service.fundTransfer(mobileNo, mobileNoReciever, amount);
					
					break;
					
				case 5 ://Balance Enquiry
						do{
							System.out.println("Enter Mobile Number to check balance");
							mobileNo = sc.next();
							if(service.validateMobileNo(mobileNo)&&service.validateAccount(mobileNo))
								break;
						}while(true);
						
						System.out.println("Current Amount "+service.checkBalance(mobileNo));
						
					break;
					
				case 6 ://Exit
						System.out.println("\nThank You for Using the Mobile Wallet!!!");
					break;
				default : System.out.println("----WARNING----Invalid input!!!");
			}
			
			
		}while(ch != 6);
		sc.close();
	}
}
