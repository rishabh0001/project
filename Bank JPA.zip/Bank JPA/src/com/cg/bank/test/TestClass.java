package com.cg.bank.test;

import org.junit.Assert;
import org.junit.Test;

import com.cg.bank.exception.BankAccountException;
import com.cg.bank.service.BankAccountService;
import com.cg.bank.service.BankAccountServiceImpl;

public class TestClass {

	@Test(expected=BankAccountException.class)
    public void test_ValidateName_null() throws BankAccountException{
        BankAccountService service=new BankAccountServiceImpl();
        service.validateName(null);
    }
    
    @Test
    public void test_validateName_v1() throws BankAccountException{
    
        String name="Aetdddse121";
        BankAccountService service=new BankAccountServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(false,result);
    }
    @Test
    public void test_validateName_v2() throws BankAccountException{
    
        String name="Ankita Singh";
        BankAccountService service=new BankAccountServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(true,result);
    }
    @Test
    public void test_validateName_v3() throws BankAccountException{
    
        String name="ankita singh";
        BankAccountService service=new BankAccountServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(false,result);
    }

  
    
    @Test
    public void test_validateMobNo_v1() throws BankAccountException{
    
        String mobNo="ABCD91828288";
        BankAccountService service=new BankAccountServiceImpl();
        boolean result= service.validateMobileNo(mobNo);
        Assert.assertEquals(false,result);
    }
    @Test
    public void test_validateMobNo_v2() throws BankAccountException{
    
        String mobNo="9922974725";
        BankAccountService service=new BankAccountServiceImpl();
        boolean result= service.validateMobileNo(mobNo);
        Assert.assertEquals(true,result);
    }
    @Test
    public void test_validateMobNo_v3() throws BankAccountException{
    
        String mobNo="992297";
        BankAccountService service=new BankAccountServiceImpl();
        boolean result= service.validateMobileNo(mobNo);
        Assert.assertEquals(false,result);
    }
	
}
